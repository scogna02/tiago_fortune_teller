class FaceRecognizer:
    def recognize_or_add(self, image):
        # Placeholder for actual face recognition logic
        # For simulation, always return 'sim_user' and False (not new)
        return "sim_user", False
